#pragma once

// planet
#include "string.h"
using namespace std;
class planet : public CWnd
{
public:
	DECLARE_DYNAMIC(planet)
	CString name;
	int radius;
	int direction;
	int positionx;
	int positiony;
	int life;
	int speed;
	planet(CString name , int radius, int direction, int pos_x, int pos_y, int life, int speed);
	

	
	virtual ~planet();

protected:
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnMerdirect();
};

class satellite : public planet 
{
public : 
	satellite(CString name , int radius, int direction, int pos_x, int pos_y, int life, int speed) : planet(name,radius,direction,pos_x,pos_y,life,speed) {}
	
};
