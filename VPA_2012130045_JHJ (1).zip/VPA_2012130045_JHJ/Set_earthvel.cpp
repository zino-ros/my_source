// Set_earthvel.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "VPA_2012130045_JHJ.h"
#include "Set_earthvel.h"


// Set_earthvel ��ȭ �����Դϴ�.

IMPLEMENT_DYNAMIC(Set_earthvel, CDialog)

Set_earthvel::Set_earthvel(CWnd* pParent /*=NULL*/)
	: CDialog(Set_earthvel::IDD, pParent)
	, m_setvel_earth(0)
{

}

Set_earthvel::~Set_earthvel()
{
}

void Set_earthvel::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_EDIT1, m_setvel_earth);
	DDV_MinMaxInt(pDX, m_setvel_earth, 1, 10);
}


BEGIN_MESSAGE_MAP(Set_earthvel, CDialog)
END_MESSAGE_MAP()


// Set_earthvel �޽��� ó�����Դϴ�.
