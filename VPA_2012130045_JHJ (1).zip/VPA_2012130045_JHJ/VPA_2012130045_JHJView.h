// VPA_2012130045_JHJView.h : CVPA_2012130045_JHJView Ŭ������ �������̽�
//


#pragma once


class CVPA_2012130045_JHJView : public CView
{
protected: // serialization������ ��������ϴ�.
	CVPA_2012130045_JHJView();
	DECLARE_DYNCREATE(CVPA_2012130045_JHJView)

// Ư���Դϴ�.
public:
	CVPA_2012130045_JHJDoc* GetDocument() const;

// �۾��Դϴ�.
public:

// �������Դϴ�.
public:
	virtual void OnDraw(CDC* pDC);  // �� �並 �׸��� ���� �����ǵǾ����ϴ�.
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
protected:
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);

// �����Դϴ�.
public:
	virtual ~CVPA_2012130045_JHJView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// ������ �޽��� �� �Լ�
protected:
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnTimer(UINT_PTR nIDEvent);
private:
	int m_degree_data;
public:
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnSimstart();
	bool m_start;
	
	
	afx_msg void OnAddSat();
	int m_simulation;
	afx_msg void OnSimstop();
	int m_count_life;
	
	int m_merdirect;
	afx_msg void OnMerdirectcw();
	afx_msg void OnMerdirectccw();
	int m_vendirect;
	afx_msg void OnVenusCw();
	afx_msg void OnVenusCcw();
	int m_eardirect;
	afx_msg void OnEarthCw();
	afx_msg void OnEarthCcw();
	
	int m_add_satellite;
	int m_merspeed;
	afx_msg void OnSetplanetVelocity();
	afx_msg void OnVelocityMercury();
	afx_msg void OnVelocityVenus();
	int m_venspeed;
	afx_msg void OnVelocityEarth();
	int m_earthspeed;
	afx_msg void OnAddplanetMars();
	int m_addmars;
	afx_msg void OnAddplanetJupiter();
	int m_addjupiter;
	afx_msg void OnDelSat();
	afx_msg void OnAddPlanet();
};

#ifndef _DEBUG  // VPA_2012130045_JHJView.cpp�� ����� ����
inline CVPA_2012130045_JHJDoc* CVPA_2012130045_JHJView::GetDocument() const
   { return reinterpret_cast<CVPA_2012130045_JHJDoc*>(m_pDocument); }
#endif

