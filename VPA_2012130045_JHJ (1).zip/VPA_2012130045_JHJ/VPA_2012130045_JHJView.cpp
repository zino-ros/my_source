// VPA_2012130045_JHJView.cpp : CVPA_2012130045_JHJView Ŭ������ ����
//

#include "stdafx.h"
#include "VPA_2012130045_JHJ.h"
#include "planet.h"
#include "VPA_2012130045_JHJDoc.h"
#include "VPA_2012130045_JHJView.h"
#include <math.h>
#ifdef _DEBUG
#define new DEBUG_NEW
#endif

//int m_merdirect= 1;
//int m_vendirect = 2;
//int m_eardirect = 1;
// CVPA_2012130045_JHJView

IMPLEMENT_DYNCREATE(CVPA_2012130045_JHJView, CView)

BEGIN_MESSAGE_MAP(CVPA_2012130045_JHJView, CView)
	// ǥ�� �μ� �����Դϴ�.
	ON_COMMAND(ID_FILE_PRINT, &CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, &CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, &CView::OnFilePrintPreview)
	ON_WM_TIMER()
	ON_WM_CREATE()
	ON_COMMAND(ID_SimStart, &CVPA_2012130045_JHJView::OnSimstart)
	
	
	ON_COMMAND(ID_ADD_Sat, &CVPA_2012130045_JHJView::OnAddSat)
	ON_COMMAND(ID_SimStop, &CVPA_2012130045_JHJView::OnSimstop)

	ON_COMMAND(ID_MerDirectCW, &CVPA_2012130045_JHJView::OnMerdirectcw)
	ON_COMMAND(ID_MerDirectCCW, &CVPA_2012130045_JHJView::OnMerdirectccw)
	ON_COMMAND(ID_VENUS_CW, &CVPA_2012130045_JHJView::OnVenusCw)
	ON_COMMAND(ID_VENUS_CCW, &CVPA_2012130045_JHJView::OnVenusCcw)
	ON_COMMAND(ID_EARTH_CW, &CVPA_2012130045_JHJView::OnEarthCw)
	ON_COMMAND(ID_EARTH_CCW, &CVPA_2012130045_JHJView::OnEarthCcw)
	
	ON_COMMAND(ID_SETPLANET_VELOCITY, &CVPA_2012130045_JHJView::OnSetplanetVelocity)
	ON_COMMAND(ID_VELOCITY_MERCURY, &CVPA_2012130045_JHJView::OnVelocityMercury)
	ON_COMMAND(ID_VELOCITY_VENUS, &CVPA_2012130045_JHJView::OnVelocityVenus)
	ON_COMMAND(ID_VELOCITY_EARTH, &CVPA_2012130045_JHJView::OnVelocityEarth)
	ON_COMMAND(ID_ADDPLANET_MARS, &CVPA_2012130045_JHJView::OnAddplanetMars)
	ON_COMMAND(ID_ADDPLANET_JUPITER, &CVPA_2012130045_JHJView::OnAddplanetJupiter)
	ON_COMMAND(ID_Del_Sat, &CVPA_2012130045_JHJView::OnDelSat)
	ON_COMMAND(ID_ADD_Planet, &CVPA_2012130045_JHJView::OnAddPlanet)
END_MESSAGE_MAP()

// CVPA_2012130045_JHJView ����/�Ҹ�

CVPA_2012130045_JHJView::CVPA_2012130045_JHJView()
: m_degree_data(0)
, m_start(false)
, m_simulation(0)
, m_count_life(0)
, m_merdirect(1)
, m_vendirect(2)
, m_eardirect(1)
, m_add_satellite(0)
, m_merspeed(1)
, m_venspeed(3)
, m_earthspeed(2)
, m_addmars(0)
, m_addjupiter(0)
{
	// TODO: ���⿡ ���� �ڵ带 �߰��մϴ�.

}

CVPA_2012130045_JHJView::~CVPA_2012130045_JHJView()
{
}

BOOL CVPA_2012130045_JHJView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: CREATESTRUCT cs�� �����Ͽ� ���⿡��
	//  Window Ŭ���� �Ǵ� ��Ÿ���� �����մϴ�.

	return CView::PreCreateWindow(cs);
}

// CVPA_2012130045_JHJView �׸���
	

void CVPA_2012130045_JHJView::OnDraw(CDC* pDC)
{
	CVPA_2012130045_JHJDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if (!pDoc)
		return;

	// TODO: ���⿡ ���� �����Ϳ� ���� �׸��� �ڵ带 �߰��մϴ�.
	planet sun(_T("Sun"),0,2,400,400,500,5);
	planet mer(_T("M"),70,m_merdirect,355,355,520,m_merspeed);
	planet venus(_T("V"),140,m_vendirect,360,360,540,m_venspeed);
	planet earth(_T("E"),210,m_eardirect,365,365,560,m_earthspeed);
	planet mars(_T("Mars"),280,1,370,370,580,3);
	planet jupiter(_T("Jup"),350,2,375,375,600,4);
	satellite moon(_T("Moon"),50,1,300,300,560,7);
	
	
	double radian_data = m_degree_data * 3.141592 / 180;
	
	pDC->SelectStockObject(NULL_BRUSH);
	pDC->Ellipse(CRect(sun.positionx-mer.radius, int(sun.positiony-mer.radius/1.5), sun.positionx+mer.radius, int(sun.positionx+mer.radius/1.5)));
	pDC->Ellipse(CRect(sun.positionx-venus.radius, int(sun.positiony-venus.radius/1.5), sun.positionx+venus.radius, int(sun.positionx+venus.radius/1.5)));
	pDC->Ellipse(CRect(sun.positionx-earth.radius, int(sun.positiony-earth.radius/1.5), sun.positionx+earth.radius, int(sun.positionx+earth.radius/1.5)));
	
	CRect Sun(sun.positionx-30,sun.positiony-20,sun.positionx+30,sun.positiony+20);
	pDC->Ellipse(&Sun);
	pDC->SelectStockObject(WHITE_BRUSH);
	pDC->DrawText(sun.name,-1,&Sun,DT_CENTER|DT_VCENTER|DT_SINGLELINE);
	
	if(m_count_life < mer.life)
	{
		if(mer.direction == 1)
		{
			CRect Mer(sun.positionx-30+int(cos(radian_data*mer.speed)*mer.radius),sun.positiony-20+int(sin(radian_data*mer.speed)*mer.radius/1.5),sun.positionx+30+int(cos(radian_data*mer.speed)*mer.radius),sun.positiony+20+int(sin(radian_data*mer.speed)*mer.radius/1.5));
			pDC->Ellipse(&Mer);
			pDC->SelectStockObject(WHITE_BRUSH);
			pDC->DrawText(mer.name,-1,&Mer,DT_CENTER|DT_VCENTER|DT_SINGLELINE);
		}
		else if(mer.direction == 2)
		{	
			
			CRect Mer(sun.positionx-30+int(sin(radian_data*mer.speed)*mer.radius),sun.positiony-20+int(cos(radian_data*mer.speed)*mer.radius/1.5),sun.positionx+30+int(sin(radian_data*mer.speed)*mer.radius),sun.positiony+20+int(cos(radian_data*mer.speed)*mer.radius/1.5));
			pDC->Ellipse(&Mer);
			pDC->SelectStockObject(WHITE_BRUSH);
			pDC->DrawText(mer.name,-1,&Mer,DT_CENTER|DT_VCENTER|DT_SINGLELINE);
		}
	}

	if(m_count_life < venus.life)
	{
		if(venus.direction == 1)
		{
			CRect Venus(sun.positionx-30+int(cos(radian_data*venus.speed)*venus.radius),sun.positiony-20+int(sin(radian_data*venus.speed)*venus.radius/1.5),sun.positionx+30+int(cos(radian_data*venus.speed)*venus.radius),sun.positiony+20+int(sin(radian_data*venus.speed)*venus.radius/1.5));
			pDC->Ellipse(&Venus);
			pDC->SelectStockObject(WHITE_BRUSH);
			pDC->DrawText(venus.name,-1,&Venus,DT_CENTER|DT_VCENTER|DT_SINGLELINE);
		}
		else if(venus.direction == 2)
		{
			CRect Venus(sun.positionx-30+int(sin(radian_data*venus.speed)*venus.radius),sun.positiony-20+int(cos(radian_data*venus.speed)*venus.radius/1.5),sun.positionx+30+int(sin(radian_data*venus.speed)*venus.radius),sun.positiony+20+int(cos(radian_data*venus.speed)*venus.radius/1.5));
			pDC->Ellipse(&Venus);
			pDC->SelectStockObject(WHITE_BRUSH);
			pDC->DrawText(venus.name,-1,&Venus,DT_CENTER|DT_VCENTER|DT_SINGLELINE);
		}
	}

	if(m_count_life < earth.life)
	{
		if(earth.direction == 1)
		{

			CRect Earth(sun.positionx-30+int(cos(radian_data*earth.speed)*earth.radius),sun.positiony-20+int(sin(radian_data*earth.speed)*earth.radius/1.5),sun.positionx+30+int(cos(radian_data*earth.speed)*earth.radius),sun.positiony+20+int(sin(radian_data*earth.speed)*earth.radius/1.5));
			pDC->Ellipse(&Earth);
			pDC->SelectStockObject(WHITE_BRUSH);
			pDC->DrawText(earth.name,-1,&Earth,DT_CENTER|DT_VCENTER|DT_SINGLELINE);
			
		}
		else if(earth.direction == 2)
		{
			CRect Earth(sun.positionx-30+int(sin(radian_data*earth.speed)*earth.radius),sun.positiony-20+int(cos(radian_data*earth.speed)*earth.radius/1.5),sun.positionx+30+int(sin(radian_data*earth.speed)*earth.radius),sun.positiony+20+int(cos(radian_data*earth.speed)*earth.radius/1.5));
			pDC->Ellipse(&Earth);
			pDC->SelectStockObject(WHITE_BRUSH);
			pDC->DrawText(earth.name,-1,&Earth,DT_CENTER|DT_VCENTER|DT_SINGLELINE);
		}
	}

	if(m_add_satellite == 1)
	{
		if(m_count_life < earth.life)
		{
			if(earth.direction == 1)
			{ 
				//pDC->SelectStockObject(NULL_BRUSH);
				//pDC->Ellipse((sun.positionx-30+int(cos(radian_data*earth.speed)*earth.radius)-30),(sun.positiony-20+int(sin(radian_data*earth.speed)*earth.radius/1.5)-30),(sun.positionx+30+int(cos(radian_data*earth.speed)*earth.radius)+30),(sun.positiony+20+int(sin(radian_data*earth.speed)*earth.radius/1.5)+30));		
				pDC->SelectStockObject(WHITE_BRUSH);
				CRect Moon((sun.positionx-30+int(cos(radian_data*earth.speed)*earth.radius)+int(sin(radian_data*earth.speed)*70)),(sun.positiony-20+int(sin(radian_data*earth.speed)*earth.radius/1.5))+int(cos(radian_data*earth.speed)*70),(sun.positionx+30+int(cos(radian_data*earth.speed)*earth.radius))+int(sin(radian_data*earth.speed)*70),(sun.positiony+20+int(sin(radian_data*earth.speed)*earth.radius/1.5))+int(cos(radian_data*earth.speed)*70));
				pDC->Ellipse(&Moon);
				pDC->DrawText(moon.name,-1,&Moon,DT_CENTER|DT_VCENTER|DT_SINGLELINE);
			}
			else if(earth.direction == 2)
			{
				pDC->SelectStockObject(WHITE_BRUSH);
				CRect Moon((sun.positionx-30+int(sin(radian_data*earth.speed)*earth.radius)+int(cos(radian_data*earth.speed)*70)),(sun.positiony-20+int(cos(radian_data*earth.speed)*earth.radius/1.5))+int(sin(radian_data*earth.speed)*70),(sun.positionx+30+int(sin(radian_data*earth.speed)*earth.radius))+int(cos(radian_data*earth.speed)*70),(sun.positiony+20+int(cos(radian_data*earth.speed)*earth.radius/1.5))+int(sin(radian_data*earth.speed)*70));
				pDC->Ellipse(&Moon);
				pDC->DrawText(moon.name,-1,&Moon,DT_CENTER|DT_VCENTER|DT_SINGLELINE);
			}	
		}
	}

	if(m_count_life < mars.life)
	{	
		if(m_addmars == 1)
		{
			pDC->SelectStockObject(NULL_BRUSH);
			pDC->Ellipse(CRect(sun.positionx-mars.radius, int(sun.positiony-mars.radius/1.5), sun.positionx+mars.radius, int(sun.positionx+mars.radius/1.5)));
			pDC->SelectStockObject(WHITE_BRUSH);
			CRect Mars(sun.positionx-30+int(sin(radian_data*mars.speed)*mars.radius),sun.positiony-20+int(cos(radian_data*mars.speed)*mars.radius/1.5),sun.positionx+30+int(sin(radian_data*mars.speed)*mars.radius),sun.positiony+20+int(cos(radian_data*mars.speed)*mars.radius/1.5));
			pDC->Ellipse(&Mars);
			pDC->DrawText(mars.name,-1,&Mars,DT_CENTER|DT_VCENTER|DT_SINGLELINE);
		}
	}
	if(m_count_life < jupiter.life)
	{
		if(m_addjupiter == 1)
		{
			pDC->SelectStockObject(NULL_BRUSH);
			pDC->Ellipse(CRect(sun.positionx-jupiter.radius, int(sun.positiony-jupiter.radius/1.5), sun.positionx+jupiter.radius, int(sun.positionx+jupiter.radius/1.5)));
			pDC->SelectStockObject(WHITE_BRUSH);
			CRect Jup(sun.positionx-30+int(sin(radian_data*jupiter.speed)*jupiter.radius),sun.positiony-20+int(cos(radian_data*jupiter.speed)*jupiter.radius/1.5),sun.positionx+30+int(sin(radian_data*jupiter.speed)*jupiter.radius),sun.positiony+20+int(cos(radian_data*jupiter.speed)*jupiter.radius/1.5));
			pDC->Ellipse(&Jup);
			pDC->DrawText(jupiter.name,-1,&Jup,DT_CENTER|DT_VCENTER|DT_SINGLELINE);
		}
	}
}

// CVPA_2012130045_JHJView �μ�

BOOL CVPA_2012130045_JHJView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// �⺻���� �غ�
	return DoPreparePrinting(pInfo);
}

void CVPA_2012130045_JHJView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: �μ��ϱ� ���� �߰� �ʱ�ȭ �۾��� �߰��մϴ�.
}

void CVPA_2012130045_JHJView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: �μ� �� ���� �۾��� �߰��մϴ�.
}


// CVPA_2012130045_JHJView ����

#ifdef _DEBUG
void CVPA_2012130045_JHJView::AssertValid() const
{
	CView::AssertValid();
}

void CVPA_2012130045_JHJView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CVPA_2012130045_JHJDoc* CVPA_2012130045_JHJView::GetDocument() const // ����׵��� ���� ������ �ζ������� �����˴ϴ�.
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CVPA_2012130045_JHJDoc)));
	return (CVPA_2012130045_JHJDoc*)m_pDocument;
}
#endif //_DEBUG


// CVPA_2012130045_JHJView �޽��� ó����

void CVPA_2012130045_JHJView::OnTimer(UINT_PTR nIDEvent)
{
	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰� ��/�Ǵ� �⺻���� ȣ���մϴ�.
	{
		if(nIDEvent==1)
		{
		m_degree_data = (m_degree_data + 2)%360;		
		Invalidate();
		m_count_life++;
		}

	}

	CView::OnTimer(nIDEvent);
}

int CVPA_2012130045_JHJView::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CView::OnCreate(lpCreateStruct) == -1)
	
	return -1;
	// TODO:  ���⿡ Ư��ȭ�� �ۼ� �ڵ带 �߰��մϴ�.
}

void CVPA_2012130045_JHJView::OnSimstart()
{
	// TODO: ���⿡ ���� ó���� �ڵ带 �߰��մϴ�.
	SetTimer(1,50,NULL);
}
void CVPA_2012130045_JHJView::OnAddSat()
{
	// TODO: ���⿡ ���� ó���� �ڵ带 �߰��մϴ�.
	m_add_satellite = 1;
}

void CVPA_2012130045_JHJView::OnSimstop()
{
	// TODO: ���⿡ ���� ó���� �ڵ带 �߰��մϴ�.
	KillTimer(1);
}

void CVPA_2012130045_JHJView::OnMerdirectcw()
{
	// TODO: ���⿡ ���� ó���� �ڵ带 �߰��մϴ�.
	m_merdirect = 1;
}

void CVPA_2012130045_JHJView::OnMerdirectccw()
{
	// TODO: ���⿡ ���� ó���� �ڵ带 �߰��մϴ�.
	m_merdirect = 2;
}

void CVPA_2012130045_JHJView::OnVenusCw()
{
	// TODO: ���⿡ ���� ó���� �ڵ带 �߰��մϴ�.
	m_vendirect = 1;
}

void CVPA_2012130045_JHJView::OnVenusCcw()
{
	// TODO: ���⿡ ���� ó���� �ڵ带 �߰��մϴ�.
	m_vendirect = 2;
}

void CVPA_2012130045_JHJView::OnEarthCw()
{
	// TODO: ���⿡ ���� ó���� �ڵ带 �߰��մϴ�.
	m_eardirect = 1;
}

void CVPA_2012130045_JHJView::OnEarthCcw()
{
	// TODO: ���⿡ ���� ó���� �ڵ带 �߰��մϴ�.
	m_eardirect = 2;
}


#include "SetVelocityDlg.h"

void CVPA_2012130045_JHJView::OnSetplanetVelocity()
{
	// TODO: ���⿡ ���� ó���� �ڵ带 �߰��մϴ�.

}

void CVPA_2012130045_JHJView::OnVelocityMercury()
{
	// TODO: ���⿡ ���� ó���� �ڵ带 �߰��մϴ�.
		SetVelocityDlg dlg;
	int res = dlg.DoModal();
	m_merspeed = dlg.m_velset;

	if(res==IDOK)
	{
		MessageBox(_T("Complete"));
		
	}
	else if(res==IDCANCEL)
	{
		MessageBox(_T("Cancel"));
	}
}
#include "Set_venvel.h"
void CVPA_2012130045_JHJView::OnVelocityVenus()
{
	// TODO: ���⿡ ���� ó���� �ڵ带 �߰��մϴ�.

	Set_venvel dlg;
	int res = dlg.DoModal();

	m_venspeed = dlg.m_setvel_venus;

	if(res==IDOK)
	{
		MessageBox(_T("Complete"));
		
	}
	else if(res==IDCANCEL)
	{
		MessageBox(_T("Cancel"));
	}


}
#include "Set_earthvel.h"
void CVPA_2012130045_JHJView::OnVelocityEarth()
{
	// TODO: ���⿡ ���� ó���� �ڵ带 �߰��մϴ�.

	Set_earthvel dlg;
	int res = dlg.DoModal();

	m_earthspeed = dlg.m_setvel_earth;

	if(res==IDOK)
	{
		MessageBox(_T("Complete"));
		
	}
	else if(res==IDCANCEL)
	{
		MessageBox(_T("Cancel"));
	}
}

void CVPA_2012130045_JHJView::OnAddplanetMars()
{
	// TODO: ���⿡ ���� ó���� �ڵ带 �߰��մϴ�.
	m_addmars = 1;
}

void CVPA_2012130045_JHJView::OnAddplanetJupiter()
{
	// TODO: ���⿡ ���� ó���� �ڵ带 �߰��մϴ�.
	m_addjupiter = 1;
}

void CVPA_2012130045_JHJView::OnDelSat()
{
	// TODO: ���⿡ ���� ó���� �ڵ带 �߰��մϴ�.
	m_add_satellite = 0;
}
#include "addplanet.h"
void CVPA_2012130045_JHJView::OnAddPlanet()
{
	// TODO: ���⿡ ���� ó���� �ڵ带 �߰��մϴ�.

	addplanet dlg;
	
	dlg.addmars=m_addmars;
	dlg.addjupiter=m_addjupiter;
	int res = dlg.DoModal();
	
	if(res==IDOK)
	{
		MessageBox(_T("Complete"));
		m_addmars = dlg.addmars;
		m_addjupiter = dlg.addjupiter;
	}
	else if(res==IDCANCEL)
	{
		MessageBox(_T("Cancel"));
	}
}
