// planet.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "VPA_2012130045_JHJ.h"
#include "planet.h"


// planet

IMPLEMENT_DYNAMIC(planet, CWnd)

planet::planet(CString n, int rad, int direct, int pos_x, int pos_y, int planet_life, int vel)
{
	name = n;
	radius = rad;
	direction = direct;
	positionx = pos_x;
	positiony = pos_y;
	life = planet_life;
	speed = vel;
}

planet::~planet()
{
}


BEGIN_MESSAGE_MAP(planet, CWnd)
	
END_MESSAGE_MAP()



// planet �޽��� ó�����Դϴ�.
