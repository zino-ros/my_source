//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by VPA_2012130045_JHJ.rc
//
#define IDD_ABOUTBOX                    100
#define IDP_OLE_INIT_FAILED             100
#define IDR_MAINFRAME                   128
#define IDR_VPA_2012130045_TYPE         129
#define IDD_DIALOG1                     130
#define IDD_DIALOG2                     131
#define IDD_DIALOG3                     132
#define IDD_DIALOG4                     133
#define IDC_EDIT1                       1002
#define IDC_RADIO1                      1003
#define IDC_RADIO2                      1004
#define ID_32771                        32771
#define ID_32772                        32772
#define ID_32773                        32773
#define ID_32774                        32774
#define ID_SimStart                     32775
#define ID_ADD_Planet                   32776
#define ID_SetPlanet                    32777
#define ID_32778                        32778
#define ID_SimStop                      32779
#define ID_32780                        32780
#define ID_ADD_Sat                      32781
#define ID_32782                        32782
#define ID_ADDPlanet                    32783
#define ID_PLANET32784                  32784
#define ID_Menu                         32785
#define ID_32786                        32786
#define ID_MerDirect                    32787
#define ID_32788                        32788
#define ID_MerDirectCW                  32789
#define ID_32790                        32790
#define ID_Mer                          32791
#define ID_MerDirectCCW                 32792
#define ID_32793                        32793
#define ID_32794                        32794
#define ID_VENUS_CW                     32795
#define ID_VENUS_CCW                    32796
#define ID_MERCURY_CW                   32797
#define ID_MERCURY_CCW                  32798
#define ID_32799                        32799
#define ID_EARTH_CW                     32800
#define ID_EARTH_CCW                    32801
#define ID_SETPLANET_VELOCITY           32802
#define ID_VELOCITY_MERCURY             32803
#define ID_VELOCITY_VENUS               32804
#define ID_VELOCITY_MERCURY32805        32805
#define ID_VELOCITY                     32806
#define ID_VELOCITY_EARTH               32807
#define ID_ADDPLANET_MARS               32808
#define ID_ADDPLANET_JUPITER            32809
#define ID_32810                        32810
#define ID_Del_Sat                      32811
#define ID_32812                        32812

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        132
#define _APS_NEXT_COMMAND_VALUE         32813
#define _APS_NEXT_CONTROL_VALUE         1005
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
