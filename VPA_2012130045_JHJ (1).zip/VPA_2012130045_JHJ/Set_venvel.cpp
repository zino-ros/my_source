// Set_venvel.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "VPA_2012130045_JHJ.h"
#include "Set_venvel.h"


// Set_venvel ��ȭ �����Դϴ�.

IMPLEMENT_DYNAMIC(Set_venvel, CDialog)

Set_venvel::Set_venvel(CWnd* pParent /*=NULL*/)
	: CDialog(Set_venvel::IDD, pParent)
	, m_setvel_venus(0)
{

}

Set_venvel::~Set_venvel()
{
}

void Set_venvel::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_EDIT1, m_setvel_venus);
	DDV_MinMaxInt(pDX, m_setvel_venus, 1, 10);
}


BEGIN_MESSAGE_MAP(Set_venvel, CDialog)
END_MESSAGE_MAP()


// Set_venvel �޽��� ó�����Դϴ�.
